package __PACKAGE_NAME__;

import android.app.Activity;
import android.os.Bundle;
__SAMPLE_IMPORT__
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
__SAMPLE_CODE__    }
}
